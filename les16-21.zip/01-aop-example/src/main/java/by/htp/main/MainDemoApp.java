package by.htp.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import by.htp.main.dao.AccountDAO;
import by.htp.main.dao.AccountDAO2;

public class MainDemoApp {

	public static void main(String[] args) {

		// read spring config java class
		AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(DemoConfig.class);
		
		System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
		
		// get the bean from spring container
		AccountDAO2 theAccountDAO = context.getBean("accountDAO2", AccountDAO2.class);
		
		// call the business method
		theAccountDAO.addAccount();

		// do it again!
		System.out.println("\nlet's call it again!\n");
		
		/*
		 * // call the business method again theAccountDAO.addAccount();
		 * 
		 * System.out.println(
		 * "||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
		 * 
		 * AccountDAO2 theAccountDAO2 = context.getBean("accountDAO2",
		 * AccountDAO2.class);
		 * 
		 * // call the business method theAccountDAO2.addAccount();
		 * 
		 * // do it again! System.out.println("\nlet's call it again!\n");
		 * 
		 * // call the business method again theAccountDAO2.addAccount();
		 * 
		 * System.out.println(
		 * "||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
		 */
		// close the context
		context.close();
	}

}










