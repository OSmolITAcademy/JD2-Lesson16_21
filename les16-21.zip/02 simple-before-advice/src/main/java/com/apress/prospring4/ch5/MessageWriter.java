package com.apress.prospring4.ch5;

public class MessageWriter {
    public void writeMessage() {
        System.out.print("World");
    }
}
