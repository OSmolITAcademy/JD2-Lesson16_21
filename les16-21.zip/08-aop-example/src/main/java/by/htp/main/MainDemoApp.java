package by.htp.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import by.htp.main.dao.AccountDAO;
import by.htp.main.dao.AccountDAO2;

public class MainDemoApp {

	public static void main(String[] args) {

		// read spring config java class
		AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(DemoConfig.class);
		
		System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
		
		// get the bean from spring container
		AccountDAO theAccountDAO = context.getBean("accountDAO", AccountDAO.class);
		
		// call the business method
		theAccountDAO.addAccount(new Account(), false);
		theAccountDAO.doWork();

		System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
		
        AccountDAO2 theAccountDAO2 = context.getBean("accountDAO2", AccountDAO2.class);
		
		// call the business method
		theAccountDAO2.addAccount2();
		theAccountDAO2.goToSleep();

		System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");

		// close the context
		context.close();
	}

}










