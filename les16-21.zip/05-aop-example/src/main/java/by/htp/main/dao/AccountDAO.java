package by.htp.main.dao;

import org.springframework.stereotype.Component;

import by.htp.main.Account;

@Component
public class AccountDAO {

	public boolean addAccount(Account theAccount, boolean vipFlag) {
		
		System.out.println(getClass() + ": DOING MY DB WORK: ADDING AN ACCOUNT");
		
		return true;
	}
}
