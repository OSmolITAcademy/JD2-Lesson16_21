package by.htp.main.dao;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO2 {

	public String addAccount2() {

		System.out.println(getClass() + ": DOING MY DB WORK: ADDING AN ACCOUNT");

		return null;
	}
}
