package by.htp.main.dao;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO {

	public boolean addAccount() {
		
		System.out.println(getClass() + ": DOING MY DB WORK: ADDING AN ACCOUNT");
		
		return true;
	}
}
