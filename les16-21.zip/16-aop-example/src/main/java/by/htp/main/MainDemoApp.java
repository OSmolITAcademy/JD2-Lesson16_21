package by.htp.main;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import by.htp.main.service.TrafficService;


public class MainDemoApp {

	public static void main(String[] args) {

		// read spring config java class
				AnnotationConfigApplicationContext context =
						new AnnotationConfigApplicationContext(DemoConfig.class);
				
				// get the bean from spring container
				TrafficService theFortuneService = 
						context.getBean("trafficService", TrafficService.class);
				
				System.out.println("\nMain Program: AroundDemoApp");
				
				System.out.println("Calling doIt");
				
				String data = theFortuneService.doIt();
				
				System.out.println("\nMy result is: " + data);
				
				System.out.println("Finished");
				
				// close the context
				context.close();
	}

}










