package by.htp.main.service;

import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Component;

@Component
public class TrafficService {

public String doIt() {
		
		// simulate a delay

		try {
			
			TimeUnit.SECONDS.sleep(5);
			System.out.println("---------------------I'm executing...");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return "Expect heavy traffic this morning";
		
	}
	
}
