package by.htp.main.service;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.springframework.stereotype.Component;

import by.htp.main.dao.DAOException;

@Component
public class TrafficService {
	private Logger myLogger = Logger.getLogger(getClass().getName());

	public String doIt() throws DAOException {

		// simulate a delay

		try {

			TimeUnit.SECONDS.sleep(5);
			myLogger.info("---------------------I'm executing...");
			//throw new DAOException("No soup.....");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return "Expect heavy traffic this morning";

	}

}
