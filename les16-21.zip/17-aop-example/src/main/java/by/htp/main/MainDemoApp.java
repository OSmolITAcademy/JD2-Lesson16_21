package by.htp.main;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import by.htp.main.dao.DAOException;
import by.htp.main.service.TrafficService;

public class MainDemoApp {
	private static Logger myLogger = Logger.getLogger(MainDemoApp.class.getName());

	public static void main(String[] args) {

		// read spring config java class
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DemoConfig.class);

		// get the bean from spring container
		TrafficService theFortuneService = context.getBean("trafficService", TrafficService.class);

		myLogger.info("\nMain Program: AroundDemoApp");

		myLogger.info("Calling doIt");

		String data = null;
		try {
			data = theFortuneService.doIt();
		} catch (DAOException e) {
			e.printStackTrace();
		}

		myLogger.info("\nMy service is: " + data);

		myLogger.info("Finished");

		// close the context
		context.close();
	}

}
