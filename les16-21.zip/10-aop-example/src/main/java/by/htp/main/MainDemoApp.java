package by.htp.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import by.htp.main.dao.AccountDAO;
import by.htp.main.dao.AccountDAO2;

public class MainDemoApp {

	public static void main(String[] args) {

		// read spring config java class
		AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(DemoConfig.class);
		
		// get the bean from spring container
		AccountDAO theAccountDAO = context.getBean("accountDAO", AccountDAO.class);
		
		// get membership bean from spring container
		AccountDAO2 theAccountDAO2 = 
				context.getBean("accountDAO2", AccountDAO2.class);
				
		// call the business method
		Account myAccount = new Account();
		theAccountDAO.addAccount(myAccount, true);
		theAccountDAO.doWork();
		
		// call the accountdao getter/setter methods
		theAccountDAO.setName("foobar");
		theAccountDAO.setServiceCode("silver");

		String name = theAccountDAO.getName();
		String code = theAccountDAO.getServiceCode();
		
		// call the membership business method
		theAccountDAO2.addSillyMember();
		theAccountDAO2.goToSleep();
		
		// close the context
		context.close();
	}

}










